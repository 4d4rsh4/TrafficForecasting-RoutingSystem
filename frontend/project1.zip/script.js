// ===== Loader =====
document.addEventListener("DOMContentLoaded", () => {
  document.body.classList.add("loading");
  window.addEventListener("load", () => {
    setTimeout(() => {
      document.body.classList.remove("loading");
      document.body.classList.add("loaded");
      document.getElementById("loader")?.classList.add("hidden");
    }, 2500);
    setTimeout(() => {
      document.body.classList.remove("loading");
      document.body.classList.add("loaded");
      document.getElementById("loader")?.classList.add("hidden");
    }, 6000);
  });
});

// ===== Full-page scroll snap JS =====
const sections = document.querySelectorAll("section");
let isScrolling = false;
let currentSection = 0;

// Scroll to a specific section
function scrollToSection(index) {
  if (index < 0) index = 0;
  if (index >= sections.length) index = sections.length - 1;
  isScrolling = true;
  sections[index].scrollIntoView({ behavior: "smooth" });
  currentSection = index;

  // update active links
  document.querySelectorAll(".nav-link").forEach((link, i) => {
    link.classList.toggle("active", i === currentSection);
  });

  // allow next scroll after smooth scroll completes
  setTimeout(() => {
    isScrolling = false;
  }, 700);
}

// Mouse wheel / trackpad scroll
window.addEventListener("wheel", (e) => {
  if (isScrolling) {
    e.preventDefault();
    return;
  }
  if (e.deltaY > 0) {
    scrollToSection(currentSection + 1);
  } else if (e.deltaY < 0) {
    scrollToSection(currentSection - 1);
  }
  e.preventDefault();
}, { passive: false });

// Keyboard arrow keys
window.addEventListener("keydown", (e) => {
  if (isScrolling) return;
  if (e.key === "ArrowDown") scrollToSection(currentSection + 1);
  if (e.key === "ArrowUp") scrollToSection(currentSection - 1);
});

// Nav link clicks
document.querySelectorAll(".nav-link").forEach((link, index) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    scrollToSection(index);
  });
});

// Prevent accidental half scroll on touch devices
let touchStartY = 0;
window.addEventListener("touchstart", (e) => {
  touchStartY = e.touches[0].clientY;
});
window.addEventListener("touchend", (e) => {
  let touchEndY = e.changedTouches[0].clientY;
  if (Math.abs(touchEndY - touchStartY) > 50) {
    if (touchEndY < touchStartY) scrollToSection(currentSection + 1);
    if (touchEndY > touchStartY) scrollToSection(currentSection - 1);
  }
});
const mapBox = document.getElementById("mapBox");

mapBox.addEventListener("click", () => {
  mapBox.classList.toggle("fullscreen");
});
const weatherButton = document.getElementById("getWeather");

weatherButton.addEventListener("click", () => {

  // Get inputs
  const city = document.getElementById("cityInput").value.trim();
  const country = document.getElementById("country").value;

  // Validate city
  if (city === "") {
    alert("Please enter a city name");
    return;
  }

  // 🔑 Replace with your OpenWeather API key
  const API_KEY = "60113eebfa2a32dd1c9fb1db11859a0c";

  // Fetch weather data
  fetch(
    `https://api.openweathermap.org/data/2.5/weather?q=${city},${country}&units=metric&appid=${API_KEY}`
  )
    .then(response => response.json())
    .then(data => {

      // If city not found
      if (data.cod !== 200) {
        alert("City not found");
        return;
      }

      // Update weather UI
      document.getElementById("w-city").innerText =
        data.name + ", " + data.sys.country;

      document.getElementById("w-temp").innerText =
        Math.round(data.main.temp) + " °C";

      document.getElementById("w-desc").innerText =
        data.weather[0].description;
    })
    .catch(() => {
      alert("Error fetching weather data");
    });
});